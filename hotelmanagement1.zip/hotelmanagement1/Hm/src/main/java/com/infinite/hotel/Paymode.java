package com.infinite.hotel;

public enum Paymode {
	ONLINE,CASH

}