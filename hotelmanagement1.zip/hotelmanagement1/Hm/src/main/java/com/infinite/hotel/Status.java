package com.infinite.hotel;

public enum Status {
	AVAILABLE,BOOKED

}